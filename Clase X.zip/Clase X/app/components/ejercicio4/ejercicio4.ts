/**
 * Ejercicio 4
 * dadas dos listas de palabras, retorne una unica lista en la cual se encuentren las palabras
 * que existan en las dos listas iniciales, además ordene esta última lista de manera que las
 * palabras repetidas más veces en ambos arreglos se encuentren al inicio de la lista.
 *
 * ejem:
 * ["rat", "dog", "cat", "parrot", "cat"] y ["cat", "lizard", "rat", "cat"] devolverán ["cat", "rat"]
 */
function repetido (a:string[],b:string[]){
    const result:string[]=[];
    for (let i = 0; i < a.length; i++) {
        const e = a[i];
        for ( let p = 0; p < b.length; p++) {
            const t = b[p];
            if (e===t) {
                result.push(e);
            }
        }
    }
    function primero (a:string[]){
    let variable='';
    let contador=0;
    let cuenta=0;
    a.map(p=>{
        cuenta=0;
        a.map(x=>{
            if (p===x) {
                cuenta++;
            }
        });
            if (cuenta>contador) {
                contador=cuenta;
                variable=p;
        } 
    });
    a.splice(0,0,variable);
}
primero(result);

    const unicos = result.filter((valor, indice) => {
        return result.indexOf(valor) === indice;
      }
    );
    return(unicos);
}
export default repetido;