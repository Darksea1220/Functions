/**
 * ejercicio 1
 * cree una función que recibe 2 arreglos como parametros.
 * luego combina estos arreglos en uno solo, alternando sus valores.
 *
 * ejem: dados los arreglos ["h", "a", "c"] y [7, 4, 17, 10, 48],
 * la respuesta deber ser: ["h", 7, "a", 4, "c", 17, 10, 48]
 *
 * note que los arreglos pueden ser de diferente tamaños y el contenido puede ser cualquier tipo de dato
 */
function sumar (a:any[]=[],b:number[]=[]){
  let counter=1;
  for (let i = 0; i < b.length; i++) {
    const c = b[i];
    a.splice(counter,0,c);
    counter=counter+2;
  }
  return a; 
}
export default sumar;