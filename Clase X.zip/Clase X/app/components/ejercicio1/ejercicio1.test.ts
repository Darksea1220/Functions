/**
 * @jest-environment jsdom
*/
import sumar from './ejercicio1';

test('Se mezclan',()=>{
  const suma=sumar(['h', 'a', 'c'], [7, 4, 17, 10, 48]);
    expect(suma).toEqual(['h', 7, 'a', 4, 'c', 17, 10, 48]);
});