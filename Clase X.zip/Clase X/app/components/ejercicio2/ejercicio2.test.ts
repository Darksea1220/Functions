/**
 * @jest-environment jsdom
*/
import parimpar from './ejercicio2';

test('Se separan',()=>{
    const test=parimpar([1,2,3,4]);
      expect(test).toEqual([2,4]);
  });