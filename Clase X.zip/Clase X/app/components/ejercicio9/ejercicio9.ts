/**
 * Ejercicio 9
 * calcular el factorial de un número
 */
 function factorial (a:number) {
	let reversa = 1; 
	for (let i=1; i<=a; i++) {
		reversa = reversa * i; 
	}
	return reversa; 
}

export default factorial;