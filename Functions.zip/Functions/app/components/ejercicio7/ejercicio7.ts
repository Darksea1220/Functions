/**
 * Ejercicio 7
 * Print integers 1 to N, but print “Fizz” if an integer is divisible by 3, “Buzz” if an integer is divisible
 * by 5, and “FizzBuzz” if an integer is divisible by both 3 and 5
 * no hablo takataka
 */

 function division(a:number){
     let cuenta = 0;
     const buzz:number[]=[];
     const fizz:number[]=[];
     const fizzbuzz:number[]=[];
     for (let i = 0; i < a; i++) {
        cuenta=cuenta+1;
        if(cuenta%3===0 && cuenta%5===0){
            fizzbuzz.push(cuenta);
        }else if(cuenta%3===0){
            buzz.push(cuenta);  
        } else if(cuenta%5===0){
            fizz.push(cuenta);
        }
    }
        if(fizzbuzz.some((e)=>e===a)){
            return 'es fizzbuzz';
        }else if(buzz.some((e)=>e===a)){
            return 'es buzz';   
        } else if(fizzbuzz.some((e)=>e===a)){
            return 'es fizz';
        }else{
            return cuenta;
        }
}
export default division;