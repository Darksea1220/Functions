/**
 * @jest-environment jsdom
*/
import division from './ejercicio7';

test('Se dividió',()=>{
    const ord=division(15);
      expect(ord).toEqual('es fizzbuzz');
    });