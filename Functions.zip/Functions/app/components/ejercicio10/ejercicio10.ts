/**
 * Ejercicio 10
 * cree una funcion que simule el lanzamiento de dos dados. Hacer uso de la función Math.random para
 * obtener números aleatorios entre 1 y 6 para cada uno de los lanzamientos de los dados. Sumar el
 * resultado de lanzar dos dados y anotar en un objeto el número de apariciones de dicha suma.
 * ejemplo del resultado:
 * const result = { "7": 3, "2": 1 }
 */
class Dado {
    numero:string;
    apariciones:number;
    constructor(numero:string, apariciones:number){
        this.numero=numero;
        this.apariciones=apariciones;
    }

}
 function dado(){
//F siendo las 5 en punto... hoy no saco eso
}
export default dado;