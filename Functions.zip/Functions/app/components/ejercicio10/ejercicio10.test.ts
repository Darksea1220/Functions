/**
 * @jest-environment jsdom
*/
import dado from './ejercicio10';

test('Es buena idea',()=>{
    const tir=dado();
      expect(tir).toEqual('publicar');
    });