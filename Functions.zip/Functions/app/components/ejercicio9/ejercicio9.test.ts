/**
 * @jest-environment jsdom
*/
test('Factorial',()=>{
    const fac=factorial(4);
      expect(fac).toEqual(24);
    });
import factorial from './ejercicio9';