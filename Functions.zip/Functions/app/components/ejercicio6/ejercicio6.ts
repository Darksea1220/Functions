/**
 * Ejercicio 6
 * cree una función que a partir de una arreglo de número y letras, ordene el arreglo con todas las
 * letras en las primeras posiciones (ordenadas alfabeticamente) y luego ponga todos los número
 * ordenados ascendentemente.
 *
 * ejem:
 * el arreglo ["b", 6, "a", "q", 7, 2] retornará ["a", "b", "q", 2, 6, 7]
 */
 const result:any[]=[];
 const num:number[]=[];
 let result2:any[]=[];
 function reorder(a:any[]){a.sort();
    for (let i = 0; i < a.length; i++) {
      const e = a[i];
      if(typeof(e) == 'string'){
          result.push(e);
          }else{num.push(e);}
          }result2=result.concat(num); return result2;
}
 export default reorder;