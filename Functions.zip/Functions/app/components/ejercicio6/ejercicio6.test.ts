/**
 * @jest-environment jsdom
*/
import reorder from './ejercicio6';

test('Se acomodó',()=>{
    const ord=reorder(['b', 6, 'a', 'q', 7, 2]);
      expect(ord).toEqual(['a', 'b', 'q', 2, 6, 7]);
    });