/**
 * Ejercicio 2
 * Dado un arreglo de numeros, devuelva un arreglo con dos listas en su interios,
 * la primera contendrá los números pares del arreglo y la segunda los impares
 */
 function parimpar(a:number[]) {
    const arrayp:number[]=[];
    const arrayi:number[]=[];
    for (let i = 0; i < a.length; i++) {
        const e = a[i];
        if (e%2===0) {
            arrayp.push(e);
        } else {
            arrayi.push(e);
        }
    }
return arrayp;
}
export default parimpar;