/**
 * @jest-environment jsdom
*/
import idea from './ejercicio8';

test('Es buena idea',()=>{
    const ide=idea(['buena','buena','mala']);
      expect(ide).toEqual('publicar');
    });