/**
 * Ejercicio 5
 * cree una función que reciba dos arreglos y verifique que el primero contenga todos los elementos del segundo
 */

 function verifica (a:any[],b:any[]){
    for (let i = 0; i < 3; i++) {
        const foun=b.find(algo=>{
        return algo===a[i];
      });return foun;}
}

export default verifica;