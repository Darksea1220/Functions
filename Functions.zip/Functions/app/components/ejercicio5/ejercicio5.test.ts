/**
 * @jest-environment jsdom
*/
import verifica from './ejercicio5';

test('Sí está',()=>{
    const tru=verifica([1,2,3], [1,2,3,4,5,6]);
      expect(tru).toEqual(1,2,3);
    });