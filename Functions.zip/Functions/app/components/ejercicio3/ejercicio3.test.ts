/**
 * @jest-environment jsdom
*/
import order from './ejercicio3';

test('Se organiza',()=>{
    const org=order([
        ['e','d','f'],
        ['a','c','b'],
        ['m','o','n']
    ]);
      expect(org).toEqual([['a', 'b', 'c'], 
                           ['d', 'e', 'f'], 
                           ['m', 'n', 'o']
    ]);
  });