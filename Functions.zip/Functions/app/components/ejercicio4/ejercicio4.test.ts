/**
 * @jest-environment jsdom
*/
import repetido from './ejercicio4';

test('Se repiten',()=>{
    const rep=repetido(['rat', 'dog', 'cat', 'parrot', 'cat'], ['cat', 'lizard', 'rat', 'cat']);
      expect(rep).toEqual(['cat','rat']);
    });